import { supabase } from '../supabase.js';
export async function setupChat(userId) {
  const chatArea = document.getElementById('chatArea');
  chatArea.innerHTML = `
    <textarea id="messageText" placeholder="Type a message..."></textarea>
    <input id="receiverId" placeholder="Receiver ID" />
    <button id="sendBtn">Send</button>
    <div id="messages"></div>
  `;
  document.getElementById('sendBtn').addEventListener('click', async () => {
    const text = document.getElementById('messageText').value;
    const to = document.getElementById('receiverId').value;
    const { error } = await supabase.from('messages').insert({
      sender_id: userId,
      receiver_id: to,
      message: text
    });
    if (error) alert(error.message); else loadMessages(userId);
  });
  await loadMessages(userId);
}
async function loadMessages(userId) {
  const { data, error } = await supabase
    .from('messages')
    .select('*')
    .or('sender_id.eq.' + userId + ',receiver_id.eq.' + userId)
    .order('created_at', { ascending: false });
  const messagesDiv = document.getElementById('messages');
  if (error) {
    messagesDiv.innerHTML = "Failed to load messages."; return;
  }
  messagesDiv.innerHTML = data.map(m => `<p><b>${m.sender_id}</b>: ${m.message}</p>`).join("");
}