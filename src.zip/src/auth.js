import { supabase } from './supabase.js';
export async function setupAuth() {
  const loginBtn = document.getElementById('loginBtn');
  const logoutBtn = document.getElementById('logoutBtn');
  loginBtn?.addEventListener('click', async () => {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) alert(error.message); else location.reload();
  });
  logoutBtn?.addEventListener('click', async () => {
    await supabase.auth.signOut();
    location.reload();
  });
}