import React from 'react';
import './App.css';
import { supabase } from './supabase';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>VakalatCareer</h1>
        <p>Welcome to the Legal Career Platform</p>
      </header>
    </div>
  );
}

export default App;