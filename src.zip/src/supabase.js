import { createClient } from '@supabase/supabase-js';
const supabaseUrl = 'https://sgedudziyyhkzsfktwby.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNnZWR1ZHppeXloa3pzZmt0d2J5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTQzODcyMTgsImV4cCI6MjA2OTk2MzIxOH0.YRuw33MmQf-8DRhcNeBC-uXzHNsatboO3GCjtv5_P-k';
export const supabase = createClient(supabaseUrl, supabaseKey);