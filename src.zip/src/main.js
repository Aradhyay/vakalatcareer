import { setupAuth } from './auth.js';
import { renderDashboard } from './dashboard.js';
document.addEventListener('DOMContentLoaded', async () => {
  await setupAuth();
  renderDashboard();
});