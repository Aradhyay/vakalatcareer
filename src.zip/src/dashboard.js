import { supabase } from './supabase.js';
import { setupChat } from './components/chatbox.js';
export async function renderDashboard() {
  const user = await supabase.auth.getUser();
  const app = document.getElementById('app');
  if (!user.data.user) {
    app.innerHTML = `
      <input type="email" id="email" placeholder="Email" />
      <input type="password" id="password" placeholder="Password" />
      <button id="loginBtn">Login</button>
    `;
  } else {
    const name = user.data.user.user_metadata?.name || "User";
    const role = user.data.user.user_metadata?.role || "Guest";
    app.innerHTML = `
      <h1>Welcome, ${name} (${role})</h1>
      <button id="logoutBtn">Logout</button>
      <div id="chatArea"></div>
    `;
    setupChat(user.data.user.id);
  }
}